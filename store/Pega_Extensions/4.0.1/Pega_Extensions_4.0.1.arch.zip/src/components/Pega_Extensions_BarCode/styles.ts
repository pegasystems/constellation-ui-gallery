import styled, { css } from 'styled-components';

export default styled.div(() => {
  return css`
    svg {
      max-height: 12rem;
    }
  `;
});
