import { useState, useEffect } from 'react';
import { withConfiguration, Progress, Text } from '@pega/cosmos-react-core';
import getAllFields from './utils';
import DentalChart from './DentalChart';
import '../shared/create-nonce';

export type JawLayoutProps = {
  getPConnect: () => typeof PConnect;
  readOnly?: boolean;
  heading?: string;
};

export const PegaExtensionsJawLayout = (props: JawLayoutProps) => {
  const { getPConnect, readOnly = false, heading } = props;
  const [fields, setFields] = useState<Array<any>>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>('');
  const [embedDataRef, setEmbedDataRef] = useState<string>('');
  const [statusPropName, setStatusPropName] = useState<string>('');

  const updateToothStatus = (index: number, newStatus: string) => {
    if (readOnly) return;

    setFields((prevFields) =>
      prevFields.map((field) => {
        if (field.propref && field.propref.endsWith(statusPropName)) {
          const newValues = [...field.value];
          newValues[index] = newStatus;
          return { ...field, value: newValues };
        }
        return field;
      }),
    );

    if (getPConnect && embedDataRef && statusPropName) {
      try {
        const listPath = embedDataRef.replace('[*]', '');
        // Use dynamic page reference for hierarchical form support
        const stateProps = getPConnect().getStateProps();
        const parentPageRef = stateProps?.pageReference || getPConnect().getPageReference() || 'caseInfo.content';
        const finalPageRef = `${parentPageRef}${listPath.startsWith('.') ? '' : '.'}${listPath}[${index}]`;
        const messageConfig = {
          meta: props,
          options: {
            context: getPConnect().getContextName(),
            pageReference: finalPageRef,
            referenceList: `.${listPath}`,
            target: getPConnect().getTarget(),
          },
        };
        const c11nEnv = PCore.createPConnect(messageConfig as any);
        c11nEnv.getPConnect().getActionsApi()?.updateFieldValue(`.${statusPropName}`, newStatus);
      } catch (e) {
        console.error('❌ Error calling updateFieldValue:', e);
      }
    }
  };

  useEffect(() => {
    const allFields = getAllFields(getPConnect);

    // WARNING: This is brittle. It assumes the desired field is always the first one.
    // If the field order changes in the Pega layout, this will break.
    const statusField = allFields[0];

    // Check if the field at index 0 exists and looks like the data we need.
    if (statusField && Array.isArray(statusField.value)) {
      const pageRef = statusField.pageref;
      const propName = statusField.propref?.split('.').pop() || '';

      setEmbedDataRef(pageRef);
      setStatusPropName(propName);

      try {
        // Use dynamic page reference for hierarchical form support
        const stateProps = getPConnect().getStateProps();
        const basePageRef = stateProps?.pageReference || getPConnect().getPageReference() || 'caseInfo.content';
        PCore.getContextTreeManager().addPageListNode(
          getPConnect().getContextName(),
          basePageRef,
          getPConnect().viewName ?? getPConnect().getComponentName() ?? '',
          pageRef,
          {},
        );
      } catch {
        /* Silently fail if already registered */
      }
      setFields(allFields);
    } else if (allFields.length > 0) {
      setError(getPConnect().getLocalizedValue('The first field in the layout is not a valid Field Group (List)."'));
    }
    setLoading(false);
  }, [getPConnect]);

  if (loading) {
    return <Progress placement='local' message={getPConnect().getLocalizedValue('Loading content...')} />;
  }

  if (error) {
    return <Text status='error'>{error}</Text>;
  }

  const statusCodes = fields[0]?.value || [];

  return (
    <DentalChart
      statusCodes={statusCodes}
      updateToothStatus={updateToothStatus}
      readOnly={readOnly}
      getPConnect={getPConnect}
      heading={heading}
    />
  );
};

export default withConfiguration(PegaExtensionsJawLayout);
