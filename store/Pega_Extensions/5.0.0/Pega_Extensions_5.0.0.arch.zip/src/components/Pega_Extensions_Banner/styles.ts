import styled, { css } from 'styled-components';

export default styled.div(() => {
  return css`
    margin-bottom: 0.5rem;
  `;
});
